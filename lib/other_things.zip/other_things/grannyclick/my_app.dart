import 'package:flutter/material.dart';

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
        // Define the default font family.
        fontFamily: 'Georgia',
        // Define the default TextTheme.
      ),
      home: const GrannyClickScreen(),
    );
  }
}

class GrannyClickScreen extends StatelessWidget {
  const GrannyClickScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Center(
            child: PrimaryButton(
              text: 'Click Me',
              onPressed: () async {
                // Simulate an API call
                await simulateAPICall();
                // Show a success message after the API call
              },
            ),
          ),
          const SizedBox(height: 20),
          Center(
            child: PrimaryButton(
              text: 'Click Me',
              onPressed: () async {
                await Future.delayed(const Duration(seconds: 5));

                // Simulate an API call
                try {
                  await simulateAPICall();
                } catch (e) {
                  print(e);
                }
              },
            ),
          ),
        ],
      ),
    );
  }
}

Future<void> simulateAPICall() async {
  await Future.delayed(const Duration(seconds: 2));
  print('Simulating API call...');
}

class PrimaryButton extends StatefulWidget {
  final String text;
  final Future<void> Function()? onPressed;
  const PrimaryButton({super.key, required this.text, this.onPressed});

  @override
  State<PrimaryButton> createState() => _PrimaryButtonState();
}

class _PrimaryButtonState extends State<PrimaryButton> with LoadingStateMixin {
  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<bool>(
      builder: (context, loading, child) {
        return AnimatedContainer(
          duration: const Duration(milliseconds: 500),
          width: loading ? 110 : 150,
          curve: Curves.easeInOut,
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(
              //remove the inkwell effect
              overlayColor: Colors.transparent,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8.0),
              ),
            ),
            onPressed: loading
                ? null
                : () {
                    withLoading(() async {
                      await widget.onPressed?.call();
                    });
                    var snackbar = const SnackBar(
                      content: Text('API call completed!'),
                      duration: Duration(seconds: 2),
                    );
                    ScaffoldMessenger.of(context).showSnackBar(snackbar);
                  },
            child: loading
                // ? const CircularProgressIndicator()
                ? const Text(
                    'Loading',
                    style: TextStyle(color: Colors.black),
                  )
                : Text(widget.text, key: const ValueKey('text')),
          ),
        );
      },
      valueListenable: isLoading,
    );
  }
}

mixin LoadingStateMixin<T extends StatefulWidget> on State<T> {
  final ValueNotifier<bool> isLoading = ValueNotifier<bool>(false);

  Future<void> withLoading(Future<void> Function() callback) async {
    if (isLoading.value) {
      return;
    }
    isLoading.value = true;

    try {
      await callback();
    } finally {
      isLoading.value = false;
    }
  }

  @override
  void dispose() {
    isLoading.dispose();
    super.dispose();
  }
}
